package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "transaction3")
public class Transaction {
	@Id
	@Column(name = "cust_acc")
	private String cust_acc;
	@Column(name = "cust_amount")
	private float cust_amount;
	@Column(name = "transcationType")
	private String transcationType;
	@Column(name = "description")
	private String description;
	public String getCust_acc() {
		return cust_acc;
	}
	public void setCust_acc(String cust_acc) {
		this.cust_acc = cust_acc;
	}
	public float getCust_amount() {
		return cust_amount;
	}
	public void setCust_amount(float cust_amount) {
		this.cust_amount = cust_amount;
	}
	public String getTranscationType() {
		return transcationType;
	}
	public void setTranscationType(String transcationType) {
		this.transcationType = transcationType;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

	

	}
