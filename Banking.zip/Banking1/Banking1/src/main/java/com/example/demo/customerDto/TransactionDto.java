package com.example.demo.customerDto;

public class TransactionDto {

}
