package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.model.Transaction;
import com.example.demo.service.TransactionService;

@RestController
public class TransactionController {


	@Autowired
	TransactionService transactionService;
	
	@RequestMapping(value="/transaction/add")
	public String addTransaction(@RequestBody Transaction trans) {
		return transactionService.addTransaction(trans);
	}
	
	@RequestMapping(value="/transaction/get", method=RequestMethod.GET )
	public Iterable<Transaction> getAll( ){
		return	transactionService.getAll();
		}
}
