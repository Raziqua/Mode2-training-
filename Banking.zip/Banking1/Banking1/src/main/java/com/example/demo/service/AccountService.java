package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.AccountDao;
import com.example.demo.model.Account;


@Service
public class AccountService {
	
	@Autowired
	private AccountDao accountDao;
	
	public String addaccount(Account acc) {
	accountDao.save(acc);
	return "Account details saved....";
	}
	
	public Iterable<Account> getAll() {
		return accountDao.findAll();
	}
}
