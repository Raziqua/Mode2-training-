package com.example.demo.customerDto;

public class TransactionDto {
	private String fromcust_accno;
	private String tocust_accno;
	private float cust_amount;

	public String getFromcust_accno() {
		return fromcust_accno;
	}

	public void setFromcust_accno(String fromcust_accno) {
		this.fromcust_accno = fromcust_accno;
	}

	public String getTocust_accno() {
		return tocust_accno;
	}

	public void setTocust_accno(String tocust_accno) {
		this.tocust_accno = tocust_accno;
	}

	public float getCust_amount() {
		return cust_amount;
	}

	public void setCust_amount(float cust_amount) {
		this.cust_amount = cust_amount;
	}

}
