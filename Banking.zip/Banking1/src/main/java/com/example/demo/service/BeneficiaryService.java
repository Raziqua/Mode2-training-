package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.BeneficiaryDao;
import com.example.demo.model.Beneficiary;

@Service
public class BeneficiaryService {
	@Autowired
	BeneficiaryDao beneficiaryDao;

	// Ton add the beneficiary
	public String addBeneficiary(Beneficiary beneficiary) {
		beneficiaryDao.save(beneficiary);
		return "added the beneficiary details";

	}

	// Find the beneficiary by IFSC Code
	public Beneficiary findBeneficiary(String ifscCode) {
		return beneficiaryDao.findByIfsccode(ifscCode);
	}

}
