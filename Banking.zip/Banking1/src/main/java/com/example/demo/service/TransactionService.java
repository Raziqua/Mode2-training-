package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import com.example.demo.customerDto.TransactionDto;
import com.example.demo.dao.AccountDao;
import com.example.demo.dao.TransactionDao;
import com.example.demo.exception.BalanceInsufficientException;
import com.example.demo.exception.CustAccountNumberNotFoundException;
import com.example.demo.model.Account;
import com.example.demo.model.Transaction;

@Service
public class TransactionService {

	float fromBalance, toBalance;

	ModelMapper modelmapper = new ModelMapper();
	@Autowired
	private AccountDao accountDao;

	@Autowired
	private TransactionDao transactionDao;

	public String addTransaction(Transaction trans) {
		transactionDao.save(trans);
		return "Transaction details saved....";
	}

	public Iterable<Transaction> getAll() {
		return transactionDao.findAll();
	}

	// To update the amount details in account
	public String transaction1(Transaction trans1, Account acc1, String to_cust) {
		transactionDao.save(trans1);
		Transaction translist = transactionDao.findById(trans1.getCust_acc()).orElse(trans1);
		Account acclist1 = accountDao.findById(trans1.getCust_acc()).orElse(acc1);// sender
		Account acclist2 = accountDao.findById(to_cust).orElse(acc1);// receiver
		if (translist.getCust_amount() < acclist1.getBalance()) {
			System.out.println("You have sufficient balance to make transaction!!");
			fromBalance = acclist1.getBalance();
			toBalance = acclist2.getBalance();
			fromBalance = fromBalance - translist.getCust_amount();
			toBalance = toBalance + translist.getCust_amount();
			acclist1.setBalance(fromBalance);
			acclist2.setBalance(toBalance);
			accountDao.save(acclist1);
			accountDao.save(acclist2);
			trans1.setCust_acc(to_cust);
			trans1.setCust_amount(translist.getCust_amount());
			trans1.setDescription("Recieved from" + translist.getCust_acc());
			trans1.setTranscation_type("credited");
			transactionDao.save(trans1);
			return "Transaction Over";
		} else {
			throw new BalanceInsufficientException("Balance is insufficient: " + acclist1.getBalance());
		}

		// return "your balance is less, you can't make transaction";
	}

	public String transaction2(TransactionDto transdto) {
		Account acc3 = new Account();
		List<TransactionDto> list = new ArrayList();
		list.add(modelmapper.map(acc3, TransactionDto.class));
		Account acclist1 = accountDao.findById(transdto.getFromcust_accno()).orElse(null);
		Account acclist2 = accountDao.findById(transdto.getTocust_accno()).orElse(null);
		Transaction trans = new Transaction();
		trans.setCust_acc(transdto.getFromcust_accno());
		trans.setCust_amount(transdto.getCust_amount());
		trans.setDescription("sent to" + transdto.getTocust_accno());
		trans.setTranscation_type("Debit");
		transactionDao.save(trans);
		if (transdto.getCust_amount() < acclist1.getBalance()) {
			System.out.println("You have sufficient balance to make transaction!!");
			fromBalance = acclist1.getBalance();
			toBalance = acclist2.getBalance();
			fromBalance = fromBalance - transdto.getCust_amount();
			toBalance = toBalance + transdto.getCust_amount();
			acclist1.setBalance(fromBalance);
			acclist2.setBalance(toBalance);
			accountDao.save(acclist1);
			accountDao.save(acclist2);
			trans.setCust_acc(transdto.getTocust_accno());
			trans.setCust_amount(transdto.getCust_amount());
			trans.setDescription("Received from" + transdto.getFromcust_accno());
			trans.setTranscation_type("credited");
			transactionDao.save(trans);
			return "Transaction Over";
			// return list;
		}
		return "Your balance is less, you can't make transaction";
	}

	public TransactionDto getTransactionDetails(String cust_acc) {
		Transaction accNum = transactionDao.findById(cust_acc).orElse(null);
		if (accNum == null) {
			throw new CustAccountNumberNotFoundException("AccNum not found: " + cust_acc);
		}
		TransactionDto transdto = modelmapper.map(accNum, TransactionDto.class);
		return transdto;
	}

	// Paging and sorting
	public List<Transaction> getAllTransactions(Integer pageNo,
			Integer pageSize/* , String sortBy */) {
		Pageable paging = PageRequest.of(pageNo, pageSize/* , Sort.by(sortBy) */);
		Page<Transaction> pagedResult = transactionDao.findAll(paging);
		if (pagedResult.hasContent()) {
			return pagedResult.getContent();
		} else {
			return new ArrayList<Transaction>();
		}
	}
}
