package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Beneficiary;
import com.example.demo.service.BeneficiaryService;

@RestController
public class BeneficiaryController {
	@Autowired
	BeneficiaryService beneficiaryService;

	@RequestMapping(value = "addBeneficiaryDetails", method = RequestMethod.POST)
	public String addBeneficiary(@RequestBody Beneficiary beneficiary) {
		return beneficiaryService.addBeneficiary(beneficiary);
	}

	@RequestMapping(value = "/findBeneficiaryDetails/{ifscCode}", method = RequestMethod.POST)
	public Beneficiary findBeneficiary(@PathVariable String ifscCode) {
		Beneficiary beneficiary = beneficiaryService.findBeneficiary(ifscCode);
		return beneficiary;
	}

}
