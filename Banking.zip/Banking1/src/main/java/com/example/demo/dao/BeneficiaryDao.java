package com.example.demo.dao;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Beneficiary;

public interface BeneficiaryDao extends CrudRepository<Beneficiary, String> {
	Beneficiary findByIfsccode(String ifscCode);
}
