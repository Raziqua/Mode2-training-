package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.customerDto.CustomerDto;
import com.example.demo.dao.CustomerDao;
import com.example.demo.model.Customer;

@Service
public class CustomerServiceimpl {
	private static final Logger logger = LoggerFactory.getLogger(CustomerServiceimpl.class);
	ModelMapper modelMapper = new ModelMapper();
	List<CustomerDto> list = new ArrayList();

	static int cust_id = 100;
	private int accNum = 200000;
	private int pass = 123456;

	@Autowired
	private CustomerDao customerDao;

	// To add the customer Details
	public String addCustomerDetails(Customer cust) {
		if (cust.getCust_age() >= 21) {
			cust.setCust_id(cust_id++);
			cust.setCust_acc("SBI" + (accNum++));
			cust.setCust_passwd("vagar" + (pass++) + "rr");
			customerDao.save(cust);
			return "Successfully Saved";
		} else {
			return "Not eligible to have account";
		}
	}

	public Iterable<Customer> getAll() {
		return customerDao.findAll();
	}

	// Get the customer details by entering the customer Id
	public Optional<Customer> getCustomerById(Integer cust_Id) {
		return customerDao.findById(cust_Id);
	}

	// Delete the customer details by customer Id
	public void deleteById(Integer cust_id1) {
		customerDao.deleteById(cust_id1);
	}

	// To Update the customer details
	public void updateById(Integer cust_id2, Customer cust3) {
		Customer details = customerDao.findById(cust_id2).orElse(cust3);
		details.setCust_email(cust3.getCust_email());
		details.setCust_job(cust3.getCust_job());
		details.setCust_phoneNo(cust3.getCust_phoneNo());
		customerDao.save(details);
	}

	// To get the details only which we required
	public List<CustomerDto> getDto() {
		customerDao.findAll().forEach(customer -> convertToDTo(customer));
		return list;
	}

	private void convertToDTo(Customer customer) {
		list.add(modelMapper.map(customer, CustomerDto.class));
	}

}
