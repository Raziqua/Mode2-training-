package com.pack.movie.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.movie.dao.TheaterDao;
import com.pack.movie.model.Theater;

@Service
public class TheaterService {
	@Autowired
	private TheaterDao theaterDao;

	// To add the theater details into the database
	public String addTheaterDetails(Theater theater) {
		theaterDao.save(theater);
		return "Theater details added successfully...!!";
	}

	// To find the theater details by entering the movie name
	public List<Theater> findTheater(String movieName) {
		return theaterDao.findByMovieName(movieName);
	}
}
