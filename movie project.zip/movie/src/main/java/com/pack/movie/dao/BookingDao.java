package com.pack.movie.dao;

import org.springframework.data.repository.CrudRepository;

import com.pack.movie.model.Booking;

public interface BookingDao extends CrudRepository<Booking, String> {

}
