package com.pack.movie.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.movie.dao.BookingDao;
import com.pack.movie.dao.ShowsDao;
import com.pack.movie.dao.TheaterDao;
import com.pack.movie.model.Booking;
import com.pack.movie.model.Shows;
import com.pack.movie.model.Theater;

@Service
public class BookingService {
	static int booking_id = 101;
	static int user_id = 1001;
	@Autowired
	TheaterDao theaterDao;
	@Autowired
	ShowsDao showsDao;
	@Autowired
	BookingDao bookingDao;

	// To add the details after booking the ticket
	public Booking addBooking(String movie_name, String theatre_id, String show_time) {
		Theater theater = theaterDao.findById(theatre_id).orElse(null);
		Shows shows = showsDao.findById(theatre_id).orElse(null);
		Booking book = new Booking();
		book.setBookingId(("FIR" + (booking_id++)));
		book.setUserId("BID" + (user_id++));
		book.setMovieName(movie_name);
		book.setShowDate(shows.getShowDate());
		book.setTheaterName(theater.getTheaterName());
		book.setShowTime(show_time);
		return bookingDao.save(book);

	}

}
