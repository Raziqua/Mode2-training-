package com.pack.movie.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Shows")
public class Shows {
	@Id
	private String theaterId;
	private LocalDate showDate;
	private String morngShow;
	private String noonShow;
	private String evengShow;

	public String getTheaterId() {
		return theaterId;
	}

	public void setTheaterId(String theaterId) {
		this.theaterId = theaterId;
	}

	public LocalDate getShowDate() {
		return showDate;
	}

	public void setShowDate(LocalDate showDate) {
		this.showDate = showDate;
	}

	public String getMorngShow() {
		return morngShow;
	}

	public void setMorngShow(String morngShow) {
		this.morngShow = morngShow;
	}

	public String getNoonShow() {
		return noonShow;
	}

	public void setNoonShow(String noonShow) {
		this.noonShow = noonShow;
	}

	public String getEvengShow() {
		return evengShow;
	}

	public void setEvengShow(String evengShow) {
		this.evengShow = evengShow;
	}
}
