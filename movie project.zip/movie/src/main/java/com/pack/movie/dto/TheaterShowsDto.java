package com.pack.movie.dto;

public class TheaterShowsDto {
	private String theaterName;
	private String place;
	private String morngShow;
	private String noonShow;
	private String evengShow;

	public String getTheaterName() {
		return theaterName;
	}

	public void setTheaterName(String theaterName) {
		this.theaterName = theaterName;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public String getMorngShow() {
		return morngShow;
	}

	public void setMorngShow(String morngShow) {
		this.morngShow = morngShow;
	}

	public String getNoonShow() {
		return noonShow;
	}

	public void setNoonShow(String noonShow) {
		this.noonShow = noonShow;
	}

	public String getEvengShow() {
		return evengShow;
	}

	public void setEvengShow(String evengShow) {
		this.evengShow = evengShow;
	}
}
