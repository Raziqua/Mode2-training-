package com.pack.movie.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.movie.dao.MovieDao;
import com.pack.movie.dao.TheaterDao;
import com.pack.movie.model.Movie;

@Service
public class MovieService {
	@Autowired
	private MovieDao movieDao;

	// To add the movie details into the movie table
	public String addMovieDetails(Movie movie) {
		movieDao.save(movie);
		return "Movie details added successfully...!!";

	}

}
