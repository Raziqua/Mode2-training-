package com.pack.movie.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pack.movie.model.Movie;
import com.pack.movie.model.Theater;
import com.pack.movie.service.MovieService;
import com.pack.movie.service.TheaterService;

@RestController
public class MovieController {
	@Autowired
	MovieService movieService;

	@RequestMapping(value = "/movie/add")
	public String addMovieDetails(@RequestBody Movie movie) {
		return movieService.addMovieDetails(movie);
	}
}
