package com.pack.movie.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.pack.movie.model.Movie;

@Repository
public interface MovieDao extends CrudRepository<Movie, String> {

}
