package com.pack.movie.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pack.movie.model.Theater;
import com.pack.movie.service.TheaterService;

@RestController
public class TheaterController {
	@Autowired
	TheaterService theaterService;

	@RequestMapping(value = "/movie/theater/add")
	public String addTheaterDetails(@RequestBody Theater theater) {
		return theaterService.addTheaterDetails(theater);
	}

	@GetMapping(value = "/movie/{movieName}")
	public List<Theater> getTheater(@PathVariable String movieName) {
		return theaterService.findTheater(movieName);
	}
}
