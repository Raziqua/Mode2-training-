package com.pack.movie.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.movie.dao.ShowsDao;
import com.pack.movie.dao.TheaterDao;
import com.pack.movie.dao.UserDao;
import com.pack.movie.dto.TheaterShowsDto;
import com.pack.movie.model.Shows;
import com.pack.movie.model.Theater;

@Service
public class ShowsService {
	@Autowired
	private ShowsDao showsDao;
	@Autowired
	private TheaterDao theaterDao;

	// To add the show details into the database
	public String addShowsDetails(Shows shows) {
		showsDao.save(shows);
		return "Show details added successfully...!!";
	}

	// To show the movie details by movie name
	public List<TheaterShowsDto> showMovieDetails(String movieName) {

		List<Shows> listShow = showsDao.findByMovieName(movieName);
		Theater theatre1 = new Theater();
		List<TheaterShowsDto> list = new ArrayList<>();
		for (Shows show : listShow) {
			TheaterShowsDto tshowdto = new TheaterShowsDto();
			String theater_Id = show.getTheaterId();
			theatre1 = theaterDao.findById(theater_Id).orElse(null);
			tshowdto.setPlace(theatre1.getPlace());
			tshowdto.setTheaterName(theatre1.getTheaterName());
			tshowdto.setEvengShow(show.getEvengShow());
			tshowdto.setMorngShow(show.getMorngShow());
			tshowdto.setNoonShow(show.getNoonShow());
			list.add(tshowdto);
		}
		return list;
	}
}
