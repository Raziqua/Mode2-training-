package com.pack.movie.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pack.movie.model.Shows;
import com.pack.movie.model.Theater;

@Repository
public interface TheaterDao extends CrudRepository<Theater, String> {
	@Query(value = "select * from Theater t where t.theater_id IN (select s.theater_id from Shows s where s.morng_show=?1 or s.noon_show=?1 or s.eveng_show=?1)", nativeQuery = true)
	List<Theater> findByMovieName(String movieName);
}
