package com.pack.movie.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pack.movie.dto.TheaterShowsDto;
import com.pack.movie.model.Shows;
import com.pack.movie.service.ShowsService;

@RestController
public class ShowsController {
	@Autowired
	ShowsService showsService;

	@RequestMapping(value = "/movie/shows/add")
	public String addUserDetails(@RequestBody Shows shows) {
		return showsService.addShowsDetails(shows);
	}

	@GetMapping(value = "/movie/theater/get")
	public List<TheaterShowsDto> showMovieDetails(@RequestParam(value = "movieName") String movieName) {
		return showsService.showMovieDetails(movieName);
	}
}
