package com.pack.movie.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pack.movie.model.Booking;
import com.pack.movie.service.BookingService;

@RestController
public class BookingController {
	@Autowired
	BookingService bookingService;

	@PostMapping(value = "/movie/add/booking")
	public Booking addShowDetails(@RequestParam String movie_name, @RequestParam String theatre_id,
			@RequestParam String show_time) {
		System.out.println("Entering");

		return (Booking) bookingService.addBooking(movie_name, theatre_id, show_time);

	}

}
