package com.pack.movie.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pack.movie.dto.UserDto;
import com.pack.movie.model.User;
import com.pack.movie.service.UserService;

@RestController
public class UserController {
	@Autowired
	UserService userService;

	@RequestMapping(value = "/movie/user/add")
	public String addUserDetails(@RequestBody User user) {
		return userService.addUserDetails(user);
	}

	@PostMapping("/movie/usernum/check")
	public String usernumCheck(@RequestBody UserDto userDto) throws IOException {
		return userService.checkUserphonenum(userDto);
	}
}
