package com.pack.movie.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.pack.movie.model.Shows;

@Repository
public interface ShowsDao extends CrudRepository<Shows, String> {
	@Query(value = "select * from Shows s where s.morng_show=?1 or s.noon_show=?1 or s.eveng_show=?1", nativeQuery = true)
	public List<Shows> findByMovieName(String movieName);
}
