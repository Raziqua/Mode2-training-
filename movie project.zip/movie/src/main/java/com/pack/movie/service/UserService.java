package com.pack.movie.service;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.movie.dao.UserDao;
import com.pack.movie.dto.UserDto;
import com.pack.movie.model.User;

@Service
public class UserService {
	@Autowired
	private UserDao userDao;

	// Add the user details into the database
	public String addUserDetails(User user) {
		userDao.save(user);
		return "User details added successfully...!!";
	}

	// Gives the exception if the mobile number does not exist
	public String checkUserphonenum(UserDto userDto) throws IOException {
		int flag = 0;
		List<User> list = (List<User>) userDao.findAll();
		for (User num : list) {
			if (userDto.getPhoneNum().equalsIgnoreCase(num.getPhoneNum())) {
				flag++;
			}
		}
		if (flag == 0) {
			throw new IOException();
		} else {
			return "You have list of movies.....!!!Please check";
		}
	}
}
